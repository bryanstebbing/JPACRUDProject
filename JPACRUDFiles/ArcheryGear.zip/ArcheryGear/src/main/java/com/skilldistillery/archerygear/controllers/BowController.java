package com.skilldistillery.archerygear.controllers;

import com.skilldistillery.archerygear.data.BowDAO;

@Controller
public class BowController {

	@Autowired
	private BowDAO bowDao;
}
