package com.skilldistillery.archerygear.data;

public interface BowDAO {

}
