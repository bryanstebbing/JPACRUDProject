package com.skilldistillery.archerygear;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BowFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(BowFinderApplication.class, args);
	}

}
